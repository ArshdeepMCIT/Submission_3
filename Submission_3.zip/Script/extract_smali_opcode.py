import os

input_dir = "apk_decompiled/smali"
output_file = "G0097_BouncingGolf_Golf.opcode"

with open(output_file, "w") as out:
    for root, dirs, files in os.walk(input_dir):
        for file in files:
            if file.endswith(".smali"):
                with open(os.path.join(root, file), "r", errors="ignore") as f:
                    for line in f:
                        line=line.strip()
                        if not line or line.startswith(".") or line.startswith("#"):
                            continue
                        opcode=line.split()[0]
                        out.write(opcode+"\n")

print("Opcode extraction finished.")
