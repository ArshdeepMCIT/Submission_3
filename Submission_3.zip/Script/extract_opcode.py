#TODO write a description for this script
#@author 
#@category _NEW_
#@keybinding 
#@menupath 
#@toolbar 
#@runtime Jython


#TODO Add User Code Here

from ghidra.program.model.listing import Instruction
from java.io import FileWriter, BufferedWriter
from ghidra.util import Msg

out_path = askFile("Select output .opcode file", "Save").getAbsolutePath()

listing = currentProgram.getListing()
instructions = listing.getInstructions(True)

bw = BufferedWriter(FileWriter(out_path))
count = 0

while instructions.hasNext():
    instr = instructions.next()
    mnemonic = instr.getMnemonicString()
    if mnemonic:
        bw.write(mnemonic.lower())
        bw.newLine()
        count += 1

bw.close()

print("[+] Exported %d opcodes to %s" % (count, out_path))